
<?php $__env->startSection('titulo'); ?>
Alterar cliente = #<?php echo e($cliente->id); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('conteudo'); ?>
    <h1>Alterar cliente = #<?php echo e($cliente->id); ?></h1>
    <form method="post" action="<?php echo e(route('clientes_salvar')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($cliente->id); ?>">
        <label>Nome</label>
        <input type="text" name="nome" value="<?php echo e($cliente->nome); ?>"><br>
        <label>Telefone</label>
        <input type="text" name="telefone" value="<?php echo e($cliente->telefone); ?>"><br>
        <label>Renda</label>
        <input type="text" name="renda" value="<?php echo e($cliente->renda); ?>"><br>

        <input type="submit" value="Enviar">
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aula2803\resources\views/altera_cliente.blade.php ENDPATH**/ ?>